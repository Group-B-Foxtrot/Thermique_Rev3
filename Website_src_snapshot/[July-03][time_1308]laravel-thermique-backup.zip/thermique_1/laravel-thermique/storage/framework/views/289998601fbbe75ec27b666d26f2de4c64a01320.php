

<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
        <script>
            document.getElementById('logout-form').submit();
        </script>
    <?php endif; ?>
    
    <?php echo $__env->make('inc.sidenav', ['logo_option' => 'hidden'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Sign In</p>
        
        <div class="grid justify-items-center">
            <form class="grid justify-items-end" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/user-shield.svg" alt=""><input id="email" type="email" class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email" required autocomplete="email">
                </p>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/key.svg" alt=""><input id="password" type="password" class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password" required autocomplete="current-password">
                </p>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="mt-5">
                    <button class="flex justify-center items-center bg-green-600 w-52 h-8 mr-4 rounded-md text-white" type="submit"><img class="svg-btn mr-3" src="/assets/svg/check.svg" alt="">Sign in</button>
                </p>
                <p class="mt-5">
                    <button class= "flex justify-center items-center bg-red-500 w-52 h-8 mr-4 rounded-md text-white" type="button" onclick="window.location.href='password-recovery'"><img class="svg-btn mr-3" src="/assets/svg/exclamation-circle.svg" alt="">Forgot Password</button>
                </p>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique\resources\views/sign_in.blade.php ENDPATH**/ ?>