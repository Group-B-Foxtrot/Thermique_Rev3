

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="m-5">
        <form action="/home" method="POST" class="grid">
        <?php echo csrf_field(); ?>
            <div class="sm:flex gap-5 md:gap-10 my-5">
                <div class="flex items-center mt-2 gap-2">
                    <label for="from_date" class="w-12">From: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="from_date" id="" class="h-8 w-44 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" <?php if(isset($info['from_date'])): ?> value="<?php echo e($info['from_date']); ?>" <?php endif; ?>>
                    <input onfocus="(this.type='time')" onblur="(this.type='')" name="from_time" id="" class="h-8 w-20 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300  text-center" placeholder="HH:MM" <?php if(isset($info['from_time'])): ?> value="<?php echo e($info['from_time']); ?>" <?php endif; ?>>
                </div>
                <div class="flex items-center mt-2 gap-2">
                    <label for="to_date" class="w-12 sm:w-auto">To: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="to_date" id="" class="h-8 w-44 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" <?php if(isset($info['to_date'])): ?> value="<?php echo e($info['to_date']); ?>" <?php endif; ?>>
                    <input onfocus="(this.type='time')" onblur="(this.type='')" name="to_time" id="" class="h-8 w-20 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300  text-center" placeholder="HH:MM" <?php if(isset($info['to_time'])): ?> value="<?php echo e($info['to_time']); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="lg:flex gap-5">
                <div class="sm:flex gap-5 my-5">
                    <div class="flex items-center mt-2 gap-2">
                        <label for="gate" class="w-12">Gate: </label>
                        <select name="gate" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled <?php if (! (isset($info['gate']))): ?> selected <?php endif; ?>> Select Gate</option>
                            <option value="1" <?php if(isset($info['gate']) && $info['gate'] =='1'): ?> selected <?php endif; ?>>1</option>
                            <option value="2" <?php if(isset($info['gate']) && $info['gate'] =='2'): ?> selected <?php endif; ?>>2</option>
                            <option value="3" <?php if(isset($info['gate']) && $info['gate'] =='3'): ?> selected <?php endif; ?>>3</option>
                            <option value="4" <?php if(isset($info['gate']) && $info['gate'] =='4'): ?> selected <?php endif; ?>>4</option>
                            <option value="5" <?php if(isset($info['gate']) && $info['gate'] =='5'): ?> selected <?php endif; ?>>5</option>
                        </select>
                    </div>
                    <div class="flex items-center mt-2 gap-2">
                        <label for="dept" class="w-12">Dept:</label>
                        <select name="dept" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled <?php if (! (isset($info['dept']))): ?> selected <?php endif; ?>>Select Dept.</option>
                            <option value="CE" <?php if(isset($info['dept']) && $info['dept'] =='CE'): ?> selected <?php endif; ?>>CE</option>
                            <option value="CSE" <?php if(isset($info['dept']) && $info['dept'] =='CSE'): ?> selected <?php endif; ?>>CSE</option>
                            <option value="EECE" <?php if(isset($info['dept']) && $info['dept'] =='EECE'): ?> selected <?php endif; ?>>EECE</option>
                            <option value="ME" <?php if(isset($info['dept']) && $info['dept'] =='ME'): ?> selected <?php endif; ?>>ME</option>
                            <option value="AE" <?php if(isset($info['dept']) && $info['dept'] =='AE'): ?> selected <?php endif; ?>>AE</option>
                            <option value="NAME" <?php if(isset($info['dept']) && $info['dept'] =='NAME'): ?> selected <?php endif; ?>>NAME</option>
                            <option value="Arch" <?php if(isset($info['dept']) && $info['dept'] =='Arch'): ?> selected <?php endif; ?>>Arch</option>
                            <option value="NSE" <?php if(isset($info['dept']) && $info['dept'] =='NSE'): ?> selected <?php endif; ?>>NSE</option>
                            <option value="BME" <?php if(isset($info['dept']) && $info['dept'] =='BME'): ?> selected <?php endif; ?>>BME</option>
                            <option value="IPE" <?php if(isset($info['dept']) && $info['dept'] =='IPE'): ?> selected <?php endif; ?>>IPE</option>
                            <option value="PME" <?php if(isset($info['dept']) && $info['dept'] =='PME'): ?> selected <?php endif; ?>>PME</option>
                            <option value="Sc. & Hum." <?php if(isset($info['dept']) && $info['dept'] =='Sc. & Hum.'): ?> selected <?php endif; ?>>Sc. & Hum.</option>
                            <option value="Other" <?php if(isset($info['dept']) && $info['dept'] =='Other'): ?> selected <?php endif; ?>>Other</option>
                        </select>
                    </div>
                    <div class="flex items-center mt-2 gap-2">
                        <label for="level" class="w-12">Level: </label>
                        <select name="level" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled <?php if (! (isset($info['level']))): ?> selected <?php endif; ?>> Select Level</option>
                            <option value="1" <?php if(isset($info['level']) && $info['level'] =='1'): ?> selected <?php endif; ?>>1</option>
                            <option value="2" <?php if(isset($info['level']) && $info['level'] =='2'): ?> selected <?php endif; ?>>2</option>
                            <option value="3" <?php if(isset($info['level']) && $info['level'] =='3'): ?> selected <?php endif; ?>>3</option>
                            <option value="4" <?php if(isset($info['level']) && $info['level'] =='4'): ?> selected <?php endif; ?>>4</option>
                        </select>
                    </div>
                </div>
                <div class="lg:pt-10">
                    <div class="pt-2 pb-1">
                        <label for="">Temperature Reading:</label> 
                    </div>
                    <div class="flex items-center mb-1 gap-2">
                        <!-- slider -->
                        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>            
                        <div class="flex justify-center items-center">
                            <div x-data="range()" x-init="mintrigger(); maxtrigger()" class="relative max-w-xl w-full">
                                <div>
                                    <input name="mintemp"
                                            type="range"
                                            step="1"
                                            x-bind:min="min" x-bind:max="max"
                                            x-on:input="mintrigger"
                                            x-model="mintemp"
                                            class="absolute pointer-events-none appearance-none z-20 h-2 w-full opacity-0 cursor-pointer">
        
                                    <input name="maxtemp"
                                            type="range" 
                                            step="1"
                                            x-bind:min="min" x-bind:max="max"
                                            x-on:input="maxtrigger"
                                            x-model="maxtemp"
                                            class="absolute pointer-events-none appearance-none z-20 h-2 w-full opacity-0 cursor-pointer">
        
                                    <div class="relative z-10 h-2 w-96">
                                        <div class="absolute z-10 h-2 left-0 right-0 bottom-0 top-0 rounded-md bg-blue-400"></div>
        
                                        <div class="absolute z-20 h-2 top-0 bottom-0 rounded-md bg-indigo-500" x-bind:style="'right:'+maxthumb+'%; left:'+minthumb+'%'"></div>
        
                                        <div class="absolute z-30 w-4 h-4 top-0 left-0 bg-blue-500 rounded-full -mt-1 " x-bind:style="'left: '+minthumb+'%'"></div>
        
                                        <div class="absolute z-30 w-4 h-4 top-0 right-0 bg-blue-500 rounded-full -mt-1 " x-bind:style="'right: '+maxthumb+'%'"></div>
                                
                                    </div>
        
                                </div>
                                
                                <div class="flex items-center py-2 w-96 mb-2">
                                <div>
                                    <input disabled type="text" maxlength="5" x-on:input="mintrigger" x-model="mintemp_str" class="absolute bg-transparent  w-16 text-center" x-bind:style="'left: '+(minthumb-5)+'%'">
                                </div>
                                <div>
                                    <input disabled type="text" maxlength="5" x-on:input="maxtrigger" x-model="maxtemp_str" class="absolute bg-transparent  w-16 rounded text-center" x-bind:style="'right: '+(maxthumb-5)+'%'">
                                </div>
                                </div>
                                
                            </div>
        
                            <script>
                                function range() {
                                    return {
                                    mintemp: <?php if(isset($info['mintemp'])): ?> <?php echo e($info['mintemp']); ?> <?php else: ?> <?php echo e(95); ?> <?php endif; ?>, 
                                    maxtemp: <?php if(isset($info['maxtemp'])): ?> <?php echo e($info['maxtemp']); ?> <?php else: ?> <?php echo e(105); ?> <?php endif; ?> ,
                                    min: 90, 
                                    max: 110,
                                    minthumb: 0,
                                    maxthumb: 0, 
                                    mintemp_str: this.mintemp+"°F",
                                    maxtemp_str: this.maxtemp+"°F",
        
                                    mintrigger() {   
                                        this.mintemp = Math.min(this.mintemp, this.maxtemp-1);
                                        this.mintemp_str= this.mintemp+" °F",
                                        this.minthumb = ((this.mintemp - this.min) / (this.max - this.min)*100);
                                    },
                                    
                                    maxtrigger() {
                                        this.maxtemp = Math.max(this.maxtemp, this.mintemp+1);
                                        this.maxtemp_str= this.maxtemp+" °F", 
                                        this.maxthumb = 100 - (((this.maxtemp - this.min) / (this.max - this.min)) * 100);    
                                    }, 
                                    }
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sm:flex my-5">
                <div class="flex items-center mt-2 gap-2">
                    <label for="other_info" class="w-12">Find: </label>
                    <input name="other_info" class="h-8 w-60 p-2 border-2  border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Search by keywords or ID" <?php if(isset($info['other_info'])): ?> value="<?php echo e($info['other_info']); ?>" <?php endif; ?> autocomplete="off">
                </div>
                <div class="flex sm:justify-center w-full mt-10 sm:mt-0">
                    <p class="flex items-center mt-2 gap-2">
                        <button class= "bg-blue-600 w-52 h-8 mr-4 rounded-md text-white text-sm" type="submit">Search</button>
                    </p>
                </div>
            </div>
        </form>
    </div>
    <?php echo $__env->make('inc.table', [ 'rows' => $rows ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/dashboard.blade.php ENDPATH**/ ?>