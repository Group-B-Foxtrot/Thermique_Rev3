<?php
    use Carbon\Carbon;
    $i=1;
?>
<div class="m-5 pb-10 flex justify-center">
    <table class="text-sm text-center">
        <tr class="bg-blue-600 text-white border-2 border-blue-600">
            <th class="border-r-2 border-white">Serial No</th>
            <th class="w-40 border-l-2 border-r-2 border-white">Person ID <span class="italic"> (link) </span></th>
            <th class="w-64 border-l-2 border-r-2 border-white">Name</th>
			<th class="w-40 border-l-2 border-r-2 border-white">Category</th>
            <th class="w-52 border-l-2 border-r-2 border-white">Temperature (°F)</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Last scan (before <?php echo e(Carbon::parse($date)->toFormattedDateString()); ?>)</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Corresponding Time (Hrs)</th>
            <th class="w-36 border-l-2 border-white">Entering Gate / Booth</th>
        </th>
        <?php if(count($rows)==0): ?>
        <tr class="bg-blue-200 border-2 border-blue-600">
            <td class="border-l-2 border-r-2 border-blue-600 italic" colspan="8">Nothing to show here</td>
        </tr>
        <?php endif; ?>

        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i % 2 == 1): ?>
            <tr class="bg-white border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600"><?php echo e($i++); ?></td>
                <td class="w-40 border-l-2 border-r-2 border-blue-600"><a href="/person/<?php echo e($row->id); ?>" class="hover:text-red-600 hover:underline"><?php echo e($row->id); ?></a></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600"><?php if($row->category=="Faculty"): ?><?php echo e($row->level); ?> <?php endif; ?><?php echo e($row->name); ?></td>
				<td class="w-40 border-l-2 border-r-2 border-blue-600"><?php echo e($row->category); ?> <?php if($row->category=="Student"): ?>(L - <?php echo e($row->level); ?>)<?php endif; ?></td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600"><?php echo e($row->temperature); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toFormattedDateString()); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toTimeString()); ?></td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600"><?php echo e($row->gate); ?></td>
            </tr>
            <?php else: ?>
            <tr class="bg-blue-200 border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600"><?php echo e($i++); ?></td>
                <td class="w-40 border-l-2 border-r-2 border-blue-600"><a href="/person/<?php echo e($row->id); ?>" class="hover:text-red-600 hover:underline"><?php echo e($row->id); ?></a></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600"><?php if($row->category=="Faculty"): ?><?php echo e($row->level); ?> <?php endif; ?><?php echo e($row->name); ?></td>
				<td class="w-40 border-l-2 border-r-2 border-blue-600"><?php echo e($row->category); ?> <?php if($row->category=="Student"): ?>(Lv-<?php echo e($row->level); ?>)<?php endif; ?></td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600"><?php echo e($row->temperature); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toFormattedDateString()); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toTimeString()); ?></td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600"><?php echo e($row->gate); ?></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH /workspace/Thermique/thermique_1/laravel-thermique/resources/views/inc/table2.blade.php ENDPATH**/ ?>