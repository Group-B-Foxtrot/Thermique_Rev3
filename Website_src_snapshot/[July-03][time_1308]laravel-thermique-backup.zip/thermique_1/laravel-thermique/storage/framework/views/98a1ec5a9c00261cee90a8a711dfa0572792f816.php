<?php if(auth()->guard()->guest()): ?>
    <script>
        window.location.href='/sign-in';
    </script>
<?php endif; ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique\resources\views/inc/check_auth.blade.php ENDPATH**/ ?>