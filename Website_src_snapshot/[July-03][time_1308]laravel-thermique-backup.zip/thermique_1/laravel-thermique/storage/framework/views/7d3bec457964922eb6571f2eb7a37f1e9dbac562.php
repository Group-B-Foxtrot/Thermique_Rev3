<div class="z-50 border-r bg-white shadow-inner w-72 min-h-screen text-sm inset-y-0 left-0 fixed transform -translate-x-full transition durtion-200 ease-in-out" id="sidenav">
    <ul class="mt-20 pl-1 shadow-lg">
        <?php if(auth()->guard()->guest()): ?>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/sign-in" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Sign In</span>
                <img src="/assets/svg/sign-in-alt.svg" alt="" class="svg-label">
            </a>
        </li>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/sign-in" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Register</span>
                <img src="/assets/svg/user-plus.svg" alt="" class="svg-label">
            </a>
        </li>
        <?php endif; ?>
        
        <?php if(auth()->guard()->check()): ?>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/home" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Home</span>
                <img src="/assets/svg/home.svg" alt="" class="svg-label">
            </a>
        </li>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/notification" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Notification</span>
                <img src="/assets/svg/bell.svg" alt="" class="svg-label">
            </a>
        </li>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/manage-account" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Manage Account</span>
                <img src="/assets/svg/user-circle.svg" alt="" class="svg-label">
            </a>
        </li>
        <?php endif; ?>
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
        <li @click.away="open = false" class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl" x-data="{ open: false }">
            <a @click="open = !open" href="#" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Settings</span>
                <img src="/assets/svg/cog.svg" alt="" class="svg-label">
            </a>
            <div x-show="open" x-transition:enter="transition ease-out duration-100" x-transition:enter-start="transform opacity-0 scale-95" x-transition:enter-end="transform opacity-100 scale-100" x-transition:leave="transition ease-in duration-75" x-transition:leave-start="transform opacity-100 scale-100" x-transition:leave-end="transform opacity-0 scale-95" class="absolute right-0 w-full -mt-1 origin-top-right rounded-md shadow-lg">
                <div class="pl-2 pr-3 bg-white">
                    <a class="flex border-t border-b h-7 pl-5 items-center border-indigo-300 hover:bg-gray-200" href="#">Light Theme</a>
                    <a class="flex border-t border-b h-7 pl-5 items-center border-indigo-300 hover:bg-gray-200" href="#">Dark Theme</a>
                    <a class="flex border-t border-b h-7 pl-5 items-center border-indigo-300 hover:bg-gray-200" href="#">Alternative</a>
                    <a class="flex border-t border-b h-7 pl-5 items-center border-indigo-300 hover:bg-gray-200" href="#">Custom Palette</a>
                </div>
            </div>
        </li>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/contact-us" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Contact Us</span>
                <img src="/assets/svg/comments.svg" alt="" class="svg-label">
            </a>
        </li>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/about" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">About</span>
                <img src="/assets/svg/info.svg" alt="" class="svg-label">
            </a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="my-1 border-l-4 border-blue-700 bg-blue-200 hover:bg-blue-300 shadow-2xl">
            <a href="/sign-in" class="flex justify-between items-center py-2 pl-3 pr-10">
                <span class="font-bold">Sign Out</span>
                <img src="/assets/svg/sign-out-alt.svg" alt="" class="svg-label">
            </a>
        </li>
        <?php endif; ?>
    </ul>
</div>

<div class="z-40 bg-black fixed inset-0 right-0 opacity-75 hidden" id="shader"></div>

<div class="flex justify-between items-center h-10 lg:h-20 md:h-12">
    <div class="">
        <button id="menu-btn" class="bg-white opacity-75 ml-2 h-9 w-12 border-2 border-gray-300 flex justify-center items-center rounded-full focus:outline-none focus:ring focus:border-blue-300  lg:h-16 lg:w-20 md:h-12 md:w-16">
            <img class="h-5 lg:h-8 md:h-7 " src="/assets/svg/bars.svg" alt="">
        </button>
    </div>
    <div class="grid justify-items-end <?php if(isset($logo_option)): ?> <?php echo e($logo_option); ?> <?php endif; ?>">
        <span class="flex">
            <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
            <img src="/assets/./img/MIST_Logo.png" alt="MIST_Logo" class="h-10 lg:h-20 md:h-12">
        </span>
    </div>
</div>
<script>
    document.getElementById('menu-btn').addEventListener("click", () => {
        document.getElementById('sidenav').classList.toggle("-translate-x-full");
        document.getElementById('shader').classList.toggle("hidden");
    });
    document.getElementById('shader').addEventListener("click", () => {
        document.getElementById('sidenav').classList.toggle("-translate-x-full");
        document.getElementById('shader').classList.toggle("hidden");
    });
</script><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/inc/sidenav.blade.php ENDPATH**/ ?>