<?php
    use Carbon\Carbon;
    $i=1;
?>
<div class="m-5 flex justify-center">
    <table class="text-sm text-center">
        <tr class="bg-blue-600 text-white border-2 border-blue-600">
            <th class="border-r-2 border-white">Serial No</th>
            <th class="w-64 border-l-2 border-r-2 border-white">Person ID</th>
            <th class="w-52 border-l-2 border-r-2 border-white">Temperature (°F)</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Date</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Time (Hrs)</th>
            <th class="w-36 border-l-2 border-white">Gate / Booth</th>
        </th>
        <?php if(count($rows)==0): ?>
        <tr class="bg-blue-200 border-2 border-blue-600">
            <td class="border-l-2 border-r-2 border-blue-600 italic" colspan="6">Nothing to show here</td>
        </tr>
        <?php endif; ?>

        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i % 2 == 1): ?>
            <tr class="bg-white border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600"><?php echo e($i++); ?></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600"><a href="/person/<?php echo e($row->person_id); ?>"><?php echo e($row->person_id); ?></a></td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600"><?php echo e($row->temperature); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toFormattedDateString()); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toTimeString()); ?></td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600"><?php echo e($row->gate); ?></td>
            </tr>
            <?php else: ?>
            <tr class="bg-blue-200 border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600"><?php echo e($i++); ?></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600"><a href="/person/<?php echo e($row->person_id); ?>"><?php echo e($row->person_id); ?></a></td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600"><?php echo e($row->temperature); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toFormattedDateString()); ?></td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600"><?php echo e(Carbon::parse($row->timestamp)->toTimeString()); ?></td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600"><?php echo e($row->gate); ?></td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH C:\Users\USER\Documents\laravel-thermique\resources\views/inc/table.blade.php ENDPATH**/ ?>