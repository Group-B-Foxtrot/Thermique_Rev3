<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($page_title); ?></title>
    <link rel="stylesheet" href="/assets/styles.css">
    <link rel="stylesheet" type="text/css" href="/assets/fontawesome5.14/css/all.css">
</head>
<body class='<?php echo e($background); ?>'>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH /workspace/Thermique/thermique_1/laravel-thermique/resources/views/layouts/layout.blade.php ENDPATH**/ ?>