<?php echo e($slot); ?>

<?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>