

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', ['logo_option' => 'hidden'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <div class="grid justify-items-center mt-10">
            <p class="bg-white border-2 px-3 py-5 text-center rounded-3xl text-sm mx-10 lg:mx-40 md:mx-30 sm:mx-20" style="line-height: 1.5rem;">
                The project aims for a smarter way to monitor the entryways of an institite, official, space or any organization, designed to stop the spread of the COVID-19 virus from aninfected person. It provides facial detection, real time temperature scanning of important facial regions, RFID and timestamp logging, and automated system, all in a neat package. This project is made in a way so that it is more budget friendly and mass-producible alternative compared to similar products on the market.
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/about.blade.php ENDPATH**/ ?>