

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', ['logo_option' => 'hidden'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Password Recovery</p>
        
        <h1 class="text-center mt-5 font-bold">Please check inbox of your email. A verification code has also <br> been sent to your phone.</h1>

        <div class="grid justify-items-center">
            <p class="mt-10">Didn't receive any code?</p>
            <form class="grid justify-items-end" action="">
                <input type="hidden">
                <input type="hidden">
                <p class="mt-2">
                    <button class= "flex justify-center items-center bg-yellow-400 w-52 h-8 mr-4 rounded-md" type="submit"><img class="svg-btn mr-3" src="/assets/svg/paper-plane.svg" alt="">Resend Code</button>
                </p>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/password_notice.blade.php ENDPATH**/ ?>