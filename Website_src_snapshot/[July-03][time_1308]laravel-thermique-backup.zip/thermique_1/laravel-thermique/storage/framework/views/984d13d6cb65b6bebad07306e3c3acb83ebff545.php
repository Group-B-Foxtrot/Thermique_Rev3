<?php echo e($slot); ?>

<?php /**PATH /workspace/Thermique/thermique_1/laravel-thermique/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>