

<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="block md:hidden lg:w-7/12 md:w-6/12 justify-center">
            <div class="flex justify-center px-5 pt-11">
                <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="MIST_Logo" class="w-full max-w-lg">
            </div>
        </div>
    <div class="flex pb-20">
        <div class="w-full lg:w-5/12 md:w-6/12 md:mt-0 mt-11">
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Person ID</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/id-badge.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e($person->id); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Name</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/user.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e($person->name); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Department</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/building.svg" alt=""><span class="w-60 h-8 p-2"><span class="sm:hidden">Dept. of</span> <?php echo e($person->dept); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Level</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/list-ol.svg" alt=""><span class="w-60 h-8 p-2"><span class="sm:hidden">L -</span> <?php echo e($person->level); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">DoB</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/birthday-cake.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e(Carbon::parse($person->dob)->toFormattedDateString()); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Blood Group</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/tint.svg" alt=""><span class="w-60 h-8 p-2">To be added</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Email</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/envelope.svg" alt=""><span class="w-60 h-8 p-2">To be added</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Contact</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/mobile-alt.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e($person->contact); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Total Entries</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/fingerprint.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e($entry_count); ?></span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Last Entry</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/calendar-day.svg" alt=""><span class="w-60 h-8 p-2"><?php echo e($last_entry->toFormattedDateString()); ?> @ <?php echo e($last_entry->toTimeString()); ?></span>
                </div>
            </div>
        </div>
        <div class="hidden md:block lg:w-7/12 md:w-6/12 justify-center">
            <div class="flex justify-center px-5 py-11">
                <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="MIST_Logo" class="w-full max-w-lg">
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/person.blade.php ENDPATH**/ ?>