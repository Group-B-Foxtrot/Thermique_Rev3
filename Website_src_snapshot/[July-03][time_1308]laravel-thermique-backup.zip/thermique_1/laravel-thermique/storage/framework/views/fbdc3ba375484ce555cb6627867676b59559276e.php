

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center pt-20 pb-5">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Update Password</p>
        
        <div class="grid justify-items-center">
            <form class="grid justify-items-end" method="POST" action="<?php echo e(route('password.update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <input id="email" type="hidden" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email">
                
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/key.svg" alt=""><input id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="password" name="password" placeholder="New Password" required autocomplete="new-password">
                </p>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/unlock-alt.svg" alt=""><input id="password-confirm" class="form-control border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="password" name="password_confirmation" placeholder="Confirm Password" required autocomplete="new-password">
                </p>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/check-square.svg" alt=""><input class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="number" name="username" placeholder="Verification Code">
                </p>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="grid justify-items-center">
                    <p class="mt-10">Didn't receive any code?</p>
                    <p class="mt-2">
                        <button class= "flex justify-center items-center bg-yellow-400 w-52 h-8 mr-4 rounded-md" type="submit"><img class="svg-btn mr-3" src="/assets/svg/paper-plane.svg" alt="">Resend Code</button>
                    </p>
                </div>

                <p class="mt-5">
                    <button class="flex justify-center items-center bg-green-600 w-52 h-8 mr-4 rounded-md text-white" type="submit"><img class="svg-btn mr-3" src="/assets/svg/check.svg" alt="">Proceed</button>
                </p>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/Thermique/thermique_1/laravel-thermique/resources/views/password_update.blade.php ENDPATH**/ ?>