

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', ['logo_option' => 'md:hidden'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="flex">
        <form action="/manage-account" method="POST" class="w-full lg:w-5/12 md:w-6/12 md:mt-0 mt-11">
            <?php echo csrf_field(); ?>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Username</label>
                <div>
                    <span class="flex items-center">
                        <img class="svg-label mr-5" src="/assets/svg/user-shield.svg" alt=""><input disabled class="border-white border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300" type="text" name="username" placeholder="Username" value="<?php echo e(Auth::user()->name); ?>">
                    </span>
                    <span class="flex justify-end pr-5"><button type="button" class="text-xs text-blue-400" onclick="elem=document.getElementsByName('username')[0], elem.disabled=false, elem.classList.replace('border-white','border-black'), this.hidden=true">Change<span class="hidden">Name</span></button></span>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600 flex justify-end" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="email" class="hidden sm:block w-28 h-8 p-2 items-center">Email</label>
                <div>
                    <span class="flex items-center">
                        <img class="svg-label mr-5" src="/assets/svg/envelope.svg" alt=""><input disabled class="border-white border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300" type="email" name="email" placeholder="Email" value="<?php echo e(Auth::user()->email); ?>">
                    </span>
                    <span class="flex justify-end pr-5"><button type="button" class="text-xs text-blue-400" onclick="elem=document.getElementsByName('email')[0], elem.disabled=false, elem.classList.replace('border-white','border-black'), this.hidden=true">Change<span class="hidden">Email</span></button></span>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600 flex justify-end" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="password" class="hidden sm:block w-28 h-8 p-2 items-center">Password</label>
                <div>
                    <span class="flex items-center">
                        <img class="svg-label mr-5" src="/assets/svg/key.svg" alt=""><input disabled class="border-white border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300" type="password" name="password" placeholder="Password" value="<?php echo e(Auth::user()->password); ?>">
                    </span>
                    <span class="flex justify-end pr-5 gap-5">
                        <button type="button" class="text-xs text-blue-400"  arg='text' onclick="elem=document.getElementsByName('password')[0], temp=elem.type, elem.type=this.arg, this.arg=temp, document.querySelector('#password-msg').classList.remove('hidden')" >Show/Hide<span class="hidden">Pass</span></button>
                        <button type="button" class="text-xs text-blue-400" onclick="elem=document.getElementsByName('password')[0], elem.disabled=false, elem.classList.replace('border-white','border-black'), this.hidden=true, document.querySelector('#password-msg').classList.remove('hidden'), document.querySelector('#password_confirmation').classList.remove('hidden')">Change<span class="hidden">Pass</span></button>
                    </span>
                    <span class="flex justify-end">
                        <span class="hidden text-xs pr-1 text-red-600 italic" id="password-msg">Hashed password was fetched to enforce security.</span>
                    </span>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600 flex justify-end" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5 hidden" id="password_confirmation">
                <label for="password_confirmation" class="hidden sm:block w-28 h-8 p-2 items-center">Confirm</label>
                <div>
                    <span class="flex items-center">
                        <img class="svg-label mr-5" src="/assets/svg/unlock-alt.svg" alt=""><input class="border-white border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300" type="password" name="password_confirmation" placeholder="Confirm New Password">
                    </span>
                    <span class="flex justify-end pr-5 gap-5">
                        <button type="button" class="text-xs text-blue-400"  arg='text' onclick="elem=document.getElementsByName('password_confirmation')[0], temp=elem.type, elem.type=this.arg, this.arg=temp" >Show/Hide<span class="hidden">Re</span></button>
                    </span>
                </div>
            </div>

            <input type="hidden" name="prev_username" value="<?php echo e(Auth::user()->name); ?>">
            <input type="hidden" name="prev_email" value="<?php echo e(Auth::user()->email); ?>">
            <input type="hidden" name="prev_password" value="<?php echo e(Auth::user()->password); ?>">

            <div class="flex justify-evenly mt-10 px-5">
                <span class="hidden sm:block w-32 h-8 p-2 items-center"></span>
                <p class="flex gap-4 justify-center sm:pl-0 pl-9">
                    <button class= "flex justify-center items-center bg-red-500 w-24 h-8 rounded-md text-white" type="button" onclick="reset_form()">Undo</button>
                    <button class= "flex justify-center items-center bg-green-500 w-24 h-8 rounded-md text-white" type="submit" onclick="document.getElementsByName('email')[0].disabled=false, document.getElementsByName('username')[0].disabled=false, document.getElementsByName('password')[0].disabled=false">Save</button>
                </p>
            </div>
        </form>
        <div class="hidden md:block lg:w-7/12 md:w-6/12 justify-center">
            <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
                <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
            </div>
            <div class="flex justify-center">
                <h1 class="font-mullingar uppercase text-center text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
            </div> 
        </div>
    </div>

    <script>
        function reset_form()
        {
            document.getElementsByName('username')[0].value=document.getElementsByName('prev_username')[0].value;
            document.getElementsByName('email')[0].value=document.getElementsByName('prev_email')[0].value;
            document.getElementsByName('password')[0].value=document.getElementsByName('prev_password')[0].value;
            document.getElementsByName('password_confirmation')[0].value="";
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique1\laravel-thermique\resources\views/manage_account.blade.php ENDPATH**/ ?>