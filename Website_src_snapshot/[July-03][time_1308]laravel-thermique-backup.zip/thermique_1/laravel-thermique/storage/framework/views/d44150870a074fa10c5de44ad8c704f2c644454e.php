<?php
    use Carbon\Carbon;
    
    $date; //initialization
    if(isset($info['selected_date']))
        $date=$info['selected_date'];
    else
        $date=Carbon::now();
    
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="m-5">
        <form action="/absent-list" method="POST" class="grid">
        <?php echo csrf_field(); ?>
            <div class="md:flex gap-5 md:gap-10 my-5">
                <div class="flex items-center mt-2 gap-2">
                    <label for="selected_date" class="w-12">From: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="selected_date" id="" class="h-8 w-60 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" <?php if(isset($info['selected_date'])): ?> value="<?php echo e($info['selected_date']); ?>" <?php endif; ?>>
                </div>
                    
                <div class="lg:flex gap-5">
                    <div class="md:flex gap-5 my-5">
                        <div class="flex items-center mt-2 gap-2">
                            <label for="dept" class="w-12">Dept:</label>
                            <select name="dept" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled <?php if (! (isset($info['dept']))): ?> selected <?php endif; ?>>Select Dept.</option>
                                <option value="CE" <?php if(isset($info['dept']) && $info['dept'] =='CE'): ?> selected <?php endif; ?>>CE</option>
                                <option value="CSE" <?php if(isset($info['dept']) && $info['dept'] =='CSE'): ?> selected <?php endif; ?>>CSE</option>
                                <option value="EECE" <?php if(isset($info['dept']) && $info['dept'] =='EECE'): ?> selected <?php endif; ?>>EECE</option>
                                <option value="ME" <?php if(isset($info['dept']) && $info['dept'] =='ME'): ?> selected <?php endif; ?>>ME</option>
                                <option value="AE" <?php if(isset($info['dept']) && $info['dept'] =='AE'): ?> selected <?php endif; ?>>AE</option>
                                <option value="NAME" <?php if(isset($info['dept']) && $info['dept'] =='NAME'): ?> selected <?php endif; ?>>NAME</option>
                                <option value="Arch" <?php if(isset($info['dept']) && $info['dept'] =='Arch'): ?> selected <?php endif; ?>>Arch</option>
                                <option value="NSE" <?php if(isset($info['dept']) && $info['dept'] =='NSE'): ?> selected <?php endif; ?>>NSE</option>
                                <option value="BME" <?php if(isset($info['dept']) && $info['dept'] =='BME'): ?> selected <?php endif; ?>>BME</option>
                                <option value="IPE" <?php if(isset($info['dept']) && $info['dept'] =='IPE'): ?> selected <?php endif; ?>>IPE</option>
                                <option value="PME" <?php if(isset($info['dept']) && $info['dept'] =='PME'): ?> selected <?php endif; ?>>PME</option>
                                <option value="Sc. & Hum." <?php if(isset($info['dept']) && $info['dept'] =='Sc. & Hum.'): ?> selected <?php endif; ?>>Sc. & Hum.</option>
                                <option value="Other" <?php if(isset($info['dept']) && $info['dept'] =='Other'): ?> selected <?php endif; ?>>Other</option>
                            </select>
                        </div>
                        <div class="flex items-center mt-2 gap-2">
                            <label for="level" class="w-12">Level: </label>
                            <select name="level" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled <?php if (! (isset($info['level']))): ?> selected <?php endif; ?>> Select Level</option>
								<option value="1" <?php if(isset($info['level']) && $info['level'] =='1'): ?> selected <?php endif; ?>>Stu. L - 1</option>
								<option value="2" <?php if(isset($info['level']) && $info['level'] =='2'): ?> selected <?php endif; ?>>Stu. L - 2</option>
								<option value="3" <?php if(isset($info['level']) && $info['level'] =='3'): ?> selected <?php endif; ?>>Stu. L - 3</option>
								<option value="4" <?php if(isset($info['level']) && $info['level'] =='4'): ?> selected <?php endif; ?>>Stu. L - 4</option>
								<option value="Lec." <?php if(isset($info['level']) && $info['level'] =='Lec.'): ?> selected <?php endif; ?>>Lec.</option>
								<option value="Asst. Prof." <?php if(isset($info['level']) && $info['level'] =='Asst. Prof.'): ?> selected <?php endif; ?>>Asst. Prof.</option>
								<option value="Assoc. Prof." <?php if(isset($info['level']) && $info['level'] =='Assoc. Prof.'): ?> selected <?php endif; ?>>Assoc. Prof.</option>
								<option value="Prof." <?php if(isset($info['level']) && $info['level'] =='Prof.'): ?> selected <?php endif; ?>>Prof.</option>
                            </select>
                        </div>
						<div class="flex items-center mt-2 gap-2">
                            <label for="gate" class="w-12">Gate: </label>
                            <select name="gate" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled <?php if (! (isset($info['gate']))): ?> selected <?php endif; ?>> Select Gate</option>
                                <option value="1" <?php if(isset($info['gate']) && $info['gate'] =='1'): ?> selected <?php endif; ?>>1</option>
                                <option value="2" <?php if(isset($info['gate']) && $info['gate'] =='2'): ?> selected <?php endif; ?>>2</option>
                                <option value="3" <?php if(isset($info['gate']) && $info['gate'] =='3'): ?> selected <?php endif; ?>>3</option>
                                <option value="4" <?php if(isset($info['gate']) && $info['gate'] =='4'): ?> selected <?php endif; ?>>4</option>
                                <option value="5" <?php if(isset($info['gate']) && $info['gate'] =='5'): ?> selected <?php endif; ?>>5</option>
                            </select>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="sm:flex gap-5 my-5">
				<div class="flex items-center mt-2 gap-2">
                        	<label for="Category" class="w-12">Tyoe: </label>
                        	<select name="category" id="" class="h-8 w-44 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            	<option disabled <?php if (! (isset($info['category']))): ?> selected <?php endif; ?>> Select Category</option>
								<option value="Student" <?php if(isset($info['category']) && $info['category'] =='Student'): ?> selected <?php endif; ?>>Student</option>
								<option value="Faculty" <?php if(isset($info['category']) && $info['category'] =='Faculty'): ?> selected <?php endif; ?>>Faculty</option>
								<option value="Teaching Asst." <?php if(isset($info['category']) && $info['category'] =='Teaching Asst.'): ?> selected <?php endif; ?>>Teaching Asst.</option>
								<option value="Admin. Off." <?php if(isset($info['category']) && $info['category'] =='Admin. Off.'): ?> selected <?php endif; ?>>Admin. Off.</option>
								<option value="Sptg. Staff" <?php if(isset($info['category']) && $info['category'] =='Sptg. Staff'): ?> selected <?php endif; ?>>Sptg. Staff</option>
								<option value="Attendant" <?php if(isset($info['category']) && $info['category'] =='Attendant'): ?> selected <?php endif; ?>>Attendant</option>
                        	</select>
                    	</div>
                <div class="flex items-center mt-2 gap-2">
                    <label for="other_info" class="w-12">Find: </label>
                    <input name="other_info" class="h-8 w-60 p-2 border-2  border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Search by keywords or ID" <?php if(isset($info['other_info'])): ?> value="<?php echo e($info['other_info']); ?>" <?php endif; ?> autocomplete="off">
                </div>
                <div class="flex md:justify-center w-96 mt-10 sm:mt-0">
                    <p class="flex items-center mt-2">
                        <button class= "bg-blue-600 w-52 sm:w-20 md:w-52 h-8 rounded-md text-white text-sm" type="submit">Search</button>
                    </p>
                </div>
            </div>
        </form>
    </div>

    <div class="mx-5 mt-10 text-2xl gap-3 text-left md:text-justify lg:text-center">
        <span class="font-bold">List of persons absent on <?php echo e(Carbon::parse($date)->toFormattedDateString()); ?></span>
    </div>

    <?php echo $__env->make('inc.table2', [ 'rows' => $rows, 'date' => $date ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/Thermique/thermique_1/laravel-thermique/resources/views/absent_list.blade.php ENDPATH**/ ?>