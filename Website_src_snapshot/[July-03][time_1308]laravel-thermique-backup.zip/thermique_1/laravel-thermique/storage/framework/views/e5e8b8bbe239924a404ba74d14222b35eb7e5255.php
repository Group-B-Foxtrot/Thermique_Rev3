

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="mx-5 mt-32 mb-10 text-2xl gap-3 text-left md:text-justify lg:text-center">
        <span class="font-bold">List of persons having temperature above 100 °F (38 °C) or above </span>
        <span class="font-medium italic"> (NHS benchmark)</span>
    </div>
    <?php echo $__env->make('inc.table', [ 'rows' => $rows], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\laravel-thermique\resources\views/alert_notification.blade.php ENDPATH**/ ?>