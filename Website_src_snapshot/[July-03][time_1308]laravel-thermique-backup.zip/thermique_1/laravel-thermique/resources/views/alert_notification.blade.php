@extends('layouts.layout')

@section('content')
    @include('inc.sidenav')

    <div class="mx-5 mt-32 mb-10 text-2xl gap-3 text-left md:text-justify lg:text-center">
        <span class="font-bold">List of persons having temperature above 100 °F (38 °C) or above </span>
        <span class="font-medium italic"> (NHS benchmark)</span>
    </div>
    @include('inc.table', [ 'rows' => $rows])
@endsection