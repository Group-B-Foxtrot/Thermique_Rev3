@extends('layouts.layout')

@section('content')
    @include('inc.sidenav')

    <div class="m-5">
        <form action="/home" method="POST" class="grid">
        @csrf
            <div class="sm:flex gap-5 md:gap-10 my-5">
                <div class="flex items-center mt-2 gap-2">
                    <label for="from_date" class="w-12">From: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="from_date" id="" class="h-8 w-44 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" @if (isset($info['from_date'])) value="{{ $info['from_date'] }}" @endif>
                    <input onfocus="(this.type='time')" onblur="(this.type='')" name="from_time" id="" class="h-8 w-20 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300  text-center" placeholder="HH:MM" @if (isset($info['from_time'])) value="{{ $info['from_time'] }}" @endif>
                </div>
                <div class="flex items-center mt-2 gap-2">
                    <label for="to_date" class="w-12 sm:w-auto">To: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="to_date" id="" class="h-8 w-44 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" @if (isset($info['to_date'])) value="{{ $info['to_date'] }}" @endif>
                    <input onfocus="(this.type='time')" onblur="(this.type='')" name="to_time" id="" class="h-8 w-20 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300  text-center" placeholder="HH:MM" @if (isset($info['to_time'])) value="{{ $info['to_time'] }}" @endif>
                </div>
            </div>
            <div class="lg:flex gap-5">
                <div class="sm:flex gap-5 my-5">
                    <div class="flex items-center mt-2 gap-2">
                        <label for="gate" class="w-12">Gate: </label>
                        <select name="gate" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled @unless (isset($info['gate'])) selected @endunless> Select Gate</option>
                            <option value="1" @if (isset($info['gate']) && $info['gate'] =='1') selected @endif>1</option>
                            <option value="2" @if (isset($info['gate']) && $info['gate'] =='2') selected @endif>2</option>
                            <option value="3" @if (isset($info['gate']) && $info['gate'] =='3') selected @endif>3</option>
                            <option value="4" @if (isset($info['gate']) && $info['gate'] =='4') selected @endif>4</option>
                            <option value="5" @if (isset($info['gate']) && $info['gate'] =='5') selected @endif>5</option>
                        </select>
                    </div>
                    <div class="flex items-center mt-2 gap-2">
                        <label for="dept" class="w-12">Dept:</label>
                        <select name="dept" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled @unless (isset($info['dept'])) selected @endunless>Select Dept.</option>
                            <option value="CE" @if (isset($info['dept']) && $info['dept'] =='CE') selected @endif>CE</option>
                            <option value="CSE" @if (isset($info['dept']) && $info['dept'] =='CSE') selected @endif>CSE</option>
                            <option value="EECE" @if (isset($info['dept']) && $info['dept'] =='EECE') selected @endif>EECE</option>
                            <option value="ME" @if (isset($info['dept']) && $info['dept'] =='ME') selected @endif>ME</option>
                            <option value="AE" @if (isset($info['dept']) && $info['dept'] =='AE') selected @endif>AE</option>
                            <option value="NAME" @if (isset($info['dept']) && $info['dept'] =='NAME') selected @endif>NAME</option>
                            <option value="Arch" @if (isset($info['dept']) && $info['dept'] =='Arch') selected @endif>Arch</option>
                            <option value="NSE" @if (isset($info['dept']) && $info['dept'] =='NSE') selected @endif>NSE</option>
                            <option value="BME" @if (isset($info['dept']) && $info['dept'] =='BME') selected @endif>BME</option>
                            <option value="IPE" @if (isset($info['dept']) && $info['dept'] =='IPE') selected @endif>IPE</option>
                            <option value="PME" @if (isset($info['dept']) && $info['dept'] =='PME') selected @endif>PME</option>
                            <option value="Sc. & Hum." @if (isset($info['dept']) && $info['dept'] =='Sc. & Hum.') selected @endif>Sc. & Hum.</option>
                            <option value="Other" @if (isset($info['dept']) && $info['dept'] =='Other') selected @endif>Other</option>
                        </select>
                    </div>
                    <div class="flex items-center mt-2 gap-2">
                        <label for="level" class="w-12">Level: </label>
                        <select name="level" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            <option disabled @unless (isset($info['level'])) selected @endunless> Select Level</option>
                            <option value="1" @if (isset($info['level']) && $info['level'] =='1') selected @endif>Stu. L - 1</option>
                            <option value="2" @if (isset($info['level']) && $info['level'] =='2') selected @endif>Stu. L - 2</option>
                            <option value="3" @if (isset($info['level']) && $info['level'] =='3') selected @endif>Stu. L - 3</option>
                            <option value="4" @if (isset($info['level']) && $info['level'] =='4') selected @endif>Stu. L - 4</option>
							<option value="Lec." @if (isset($info['level']) && $info['level'] =='Lec.') selected @endif>Lec.</option>
							<option value="Asst. Prof." @if (isset($info['level']) && $info['level'] =='Asst. Prof.') selected @endif>Asst. Prof.</option>
							<option value="Assoc. Prof." @if (isset($info['level']) && $info['level'] =='Assoc. Prof.') selected @endif>Assoc. Prof.</option>
							<option value="Prof." @if (isset($info['level']) && $info['level'] =='Prof.') selected @endif>Prof.</option>
                        </select>
                    </div>
                </div>
                <div class="lg:pt-10">
                    <div class="pt-2 pb-1">
                        <label for="">Temperature Reading:</label> 
                    </div>
                    <div class="flex items-center mb-1 gap-2">
                        <!-- slider -->
                        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>            
                        <div class="flex justify-center items-center">
                            <div x-data="range()" x-init="mintrigger(); maxtrigger()" class="relative max-w-xl w-full">
                                <div>
                                    <input name="mintemp"
                                            type="range"
                                            step="1"
                                            x-bind:min="min" x-bind:max="max"
                                            x-on:input="mintrigger"
                                            x-model="mintemp"
                                            class="absolute pointer-events-none appearance-none z-20 h-2 w-full opacity-0 cursor-pointer">
        
                                    <input name="maxtemp"
                                            type="range" 
                                            step="1"
                                            x-bind:min="min" x-bind:max="max"
                                            x-on:input="maxtrigger"
                                            x-model="maxtemp"
                                            class="absolute pointer-events-none appearance-none z-20 h-2 w-full opacity-0 cursor-pointer">
        
                                    <div class="relative z-10 h-2 w-96">
                                        <div class="absolute z-10 h-2 left-0 right-0 bottom-0 top-0 rounded-md bg-blue-400"></div>
        
                                        <div class="absolute z-20 h-2 top-0 bottom-0 rounded-md bg-indigo-500" x-bind:style="'right:'+maxthumb+'%; left:'+minthumb+'%'"></div>
        
                                        <div class="absolute z-30 w-4 h-4 top-0 left-0 bg-blue-500 rounded-full -mt-1 " x-bind:style="'left: '+minthumb+'%'"></div>
        
                                        <div class="absolute z-30 w-4 h-4 top-0 right-0 bg-blue-500 rounded-full -mt-1 " x-bind:style="'right: '+maxthumb+'%'"></div>
                                
                                    </div>
        
                                </div>
                                
                                <div class="flex items-center py-2 w-96 mb-2">
                                <div>
                                    <input disabled type="text" maxlength="5" x-on:input="mintrigger" x-model="mintemp_str" class="absolute bg-transparent  w-16 text-center" x-bind:style="'left: '+(minthumb-5)+'%'">
                                </div>
                                <div>
                                    <input disabled type="text" maxlength="5" x-on:input="maxtrigger" x-model="maxtemp_str" class="absolute bg-transparent  w-16 rounded text-center" x-bind:style="'right: '+(maxthumb-5)+'%'">
                                </div>
                                </div>
                                
                            </div>
        
                            <script>
                                function range() {
                                    return {
                                    mintemp: @if (isset($info['mintemp'])) {{ $info['mintemp'] }} @else {{ 95 }} @endif, 
                                    maxtemp: @if (isset($info['maxtemp'])) {{ $info['maxtemp'] }} @else {{ 105 }} @endif ,
                                    min: 90, 
                                    max: 110,
                                    minthumb: 0,
                                    maxthumb: 0, 
                                    mintemp_str: this.mintemp+"°F",
                                    maxtemp_str: this.maxtemp+"°F",
        
                                    mintrigger() {   
                                        this.mintemp = Math.min(this.mintemp, this.maxtemp-1);
                                        this.mintemp_str= this.mintemp+"°F",
                                        this.minthumb = ((this.mintemp - this.min) / (this.max - this.min)*100);
                                    },
                                    
                                    maxtrigger() {
                                        this.maxtemp = Math.max(this.maxtemp, this.mintemp+1);
                                        this.maxtemp_str= this.maxtemp+"°F", 
                                        this.maxthumb = 100 - (((this.maxtemp - this.min) / (this.max - this.min)) * 100);    
                                    }, 
                                    }
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sm:flex gap-5 my-5">
				<div class="flex items-center mt-2 gap-2">
					<label for="Category" class="w-12">Type: </label>
					<select name="category" id="" class="h-8 w-44 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
						<option disabled @unless (isset($info['category'])) selected @endunless> Select Category</option>
						<option value="Student" @if (isset($info['category']) && $info['category'] =='Student') selected @endif>Student</option>
						<option value="Faculty" @if (isset($info['category']) && $info['category'] =='Faculty') selected @endif>Faculty</option>
						<option value="Teaching Asst." @if (isset($info['category']) && $info['category'] =='Teaching Asst.') selected @endif>Teaching Asst.</option>
						<option value="Admin. Off." @if (isset($info['category']) && $info['category'] =='Admin. Off.') selected @endif>Admin. Off.</option>
						<option value="Sptg. Staff" @if (isset($info['category']) && $info['category'] =='Sptg. Staff') selected @endif>Sptg. Staff</option>
						<option value="Attendant" @if (isset($info['category']) && $info['category'] =='Attendant') selected @endif>Attendant</option>
					</select>
				</div>
                <div class="flex items-center mt-2 gap-2">
                    <label for="other_info" class="w-12">Find: </label>
                    <input name="other_info" class="h-8 w-60 p-2 border-2  border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Search by keywords or ID" @if (isset($info['other_info'])) value="{{ $info['other_info'] }}" @endif autocomplete="off">
                </div>
                <div class="flex lg:justify-center w-96 mt-10 sm:mt-0">
                    <p class="flex items-center mt-2">
                        <button class= "bg-blue-600 w-52 sm:w-20 lg:w-52 h-8 rounded-md text-white text-sm" type="submit">Search</button>
                    </p>
                </div>
            </div>
        </form>
    </div>
    @include('inc.table', [ 'rows' => $rows ])
@endsection