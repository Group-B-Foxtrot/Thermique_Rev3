@extends('layouts.layout')

@php
    use Carbon\Carbon;
    
    $date; //initialization
    if(isset($info['selected_date']))
        $date=$info['selected_date'];
    else
        $date=Carbon::now();
    
@endphp

@section('content')
    @include('inc.sidenav')


    <div class="m-5">
        <form action="/absent-list" method="POST" class="grid">
        @csrf
            <div class="md:flex gap-5 md:gap-10 my-5">
                <div class="flex items-center mt-2 gap-2">
                    <label for="selected_date" class="w-12">From: </label>
                    <input onfocus="(this.type='date')" onblur="(this.type='')" name="selected_date" id="" class="h-8 w-60 p-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Select Date" @if (isset($info['selected_date'])) value="{{ $info['selected_date'] }}" @endif>
                </div>
                    
                <div class="lg:flex gap-5">
                    <div class="md:flex gap-5 my-5">
                        <div class="flex items-center mt-2 gap-2">
                            <label for="dept" class="w-12">Dept:</label>
                            <select name="dept" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled @unless (isset($info['dept'])) selected @endunless>Select Dept.</option>
                                <option value="CE" @if (isset($info['dept']) && $info['dept'] =='CE') selected @endif>CE</option>
                                <option value="CSE" @if (isset($info['dept']) && $info['dept'] =='CSE') selected @endif>CSE</option>
                                <option value="EECE" @if (isset($info['dept']) && $info['dept'] =='EECE') selected @endif>EECE</option>
                                <option value="ME" @if (isset($info['dept']) && $info['dept'] =='ME') selected @endif>ME</option>
                                <option value="AE" @if (isset($info['dept']) && $info['dept'] =='AE') selected @endif>AE</option>
                                <option value="NAME" @if (isset($info['dept']) && $info['dept'] =='NAME') selected @endif>NAME</option>
                                <option value="Arch" @if (isset($info['dept']) && $info['dept'] =='Arch') selected @endif>Arch</option>
                                <option value="NSE" @if (isset($info['dept']) && $info['dept'] =='NSE') selected @endif>NSE</option>
                                <option value="BME" @if (isset($info['dept']) && $info['dept'] =='BME') selected @endif>BME</option>
                                <option value="IPE" @if (isset($info['dept']) && $info['dept'] =='IPE') selected @endif>IPE</option>
                                <option value="PME" @if (isset($info['dept']) && $info['dept'] =='PME') selected @endif>PME</option>
                                <option value="Sc. & Hum." @if (isset($info['dept']) && $info['dept'] =='Sc. & Hum.') selected @endif>Sc. & Hum.</option>
                                <option value="Other" @if (isset($info['dept']) && $info['dept'] =='Other') selected @endif>Other</option>
                            </select>
                        </div>
                        <div class="flex items-center mt-2 gap-2">
                            <label for="level" class="w-12">Level: </label>
                            <select name="level" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled @unless (isset($info['level'])) selected @endunless> Select Level</option>
								<option value="1" @if (isset($info['level']) && $info['level'] =='1') selected @endif>Stu. L - 1</option>
								<option value="2" @if (isset($info['level']) && $info['level'] =='2') selected @endif>Stu. L - 2</option>
								<option value="3" @if (isset($info['level']) && $info['level'] =='3') selected @endif>Stu. L - 3</option>
								<option value="4" @if (isset($info['level']) && $info['level'] =='4') selected @endif>Stu. L - 4</option>
								<option value="Lec." @if (isset($info['level']) && $info['level'] =='Lec.') selected @endif>Lec.</option>
								<option value="Asst. Prof." @if (isset($info['level']) && $info['level'] =='Asst. Prof.') selected @endif>Asst. Prof.</option>
								<option value="Assoc. Prof." @if (isset($info['level']) && $info['level'] =='Assoc. Prof.') selected @endif>Assoc. Prof.</option>
								<option value="Prof." @if (isset($info['level']) && $info['level'] =='Prof.') selected @endif>Prof.</option>
                            </select>
                        </div>
						<div class="flex items-center mt-2 gap-2">
                            <label for="gate" class="w-12">Gate: </label>
                            <select name="gate" id="" class="h-8 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                                <option disabled @unless (isset($info['gate'])) selected @endunless> Select Gate</option>
                                <option value="1" @if (isset($info['gate']) && $info['gate'] =='1') selected @endif>1</option>
                                <option value="2" @if (isset($info['gate']) && $info['gate'] =='2') selected @endif>2</option>
                                <option value="3" @if (isset($info['gate']) && $info['gate'] =='3') selected @endif>3</option>
                                <option value="4" @if (isset($info['gate']) && $info['gate'] =='4') selected @endif>4</option>
                                <option value="5" @if (isset($info['gate']) && $info['gate'] =='5') selected @endif>5</option>
                            </select>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="sm:flex gap-5 my-5">
				<div class="flex items-center mt-2 gap-2">
                        	<label for="Category" class="w-12">Tyoe: </label>
                        	<select name="category" id="" class="h-8 w-44 pl-2 border-2 border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 ">
                            	<option disabled @unless (isset($info['category'])) selected @endunless> Select Category</option>
								<option value="Student" @if (isset($info['category']) && $info['category'] =='Student') selected @endif>Student</option>
								<option value="Faculty" @if (isset($info['category']) && $info['category'] =='Faculty') selected @endif>Faculty</option>
								<option value="Teaching Asst." @if (isset($info['category']) && $info['category'] =='Teaching Asst.') selected @endif>Teaching Asst.</option>
								<option value="Admin. Off." @if (isset($info['category']) && $info['category'] =='Admin. Off.') selected @endif>Admin. Off.</option>
								<option value="Sptg. Staff" @if (isset($info['category']) && $info['category'] =='Sptg. Staff') selected @endif>Sptg. Staff</option>
								<option value="Attendant" @if (isset($info['category']) && $info['category'] =='Attendant') selected @endif>Attendant</option>
                        	</select>
                    	</div>
                <div class="flex items-center mt-2 gap-2">
                    <label for="other_info" class="w-12">Find: </label>
                    <input name="other_info" class="h-8 w-60 p-2 border-2  border-gray-500 rounded-full focus:outline-none focus:ring focus:border-blue-300 " placeholder="Search by keywords or ID" @if (isset($info['other_info'])) value="{{ $info['other_info'] }}" @endif autocomplete="off">
                </div>
                <div class="flex md:justify-center w-96 mt-10 sm:mt-0">
                    <p class="flex items-center mt-2">
                        <button class= "bg-blue-600 w-52 sm:w-20 md:w-52 h-8 rounded-md text-white text-sm" type="submit">Search</button>
                    </p>
                </div>
            </div>
        </form>
    </div>

    <div class="mx-5 mt-10 text-2xl gap-3 text-left md:text-justify lg:text-center">
        <span class="font-bold">List of persons absent on {{Carbon::parse($date)->toFormattedDateString()}}</span>
    </div>

    @include('inc.table2', [ 'rows' => $rows, 'date' => $date ])
@endsection