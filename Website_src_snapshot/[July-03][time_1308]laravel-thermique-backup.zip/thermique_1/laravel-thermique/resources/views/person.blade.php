@extends('layouts.layout')

@php
    use Carbon\Carbon;
@endphp

@section('content')
    @include('inc.sidenav')
    <div class="block md:hidden lg:w-7/12 md:w-6/12 justify-center">
            <div class="flex justify-center px-5 pt-11">
                <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="MIST_Logo" class="w-full max-w-lg">
            </div>
        </div>
    <div class="flex pb-20">
        <div class="w-full lg:w-5/12 md:w-6/12 md:mt-0 mt-11">
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Person ID</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/id-badge.svg" alt=""><span class="w-60 h-8 p-2">{{$person->id}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Name</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/user.svg" alt=""><span class="w-60 h-8 p-2">@if ($person->category=="Faculty"){{$person->level}} @endif{{$person->name}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Department</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/building.svg" alt=""><span class="w-60 h-8 p-2"><span class="sm:hidden">Dept. of </span>{{$person->dept}}</span>
                </div>
            </div>
			@unless ($person->category=="Faculty")
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">@if ($person->category=="Student") Level @else Post @endif</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/list-ol.svg" alt=""><span class="w-60 h-8 p-2">@if ($person->category=="Student")<span class="sm:hidden">L - </span> @endif {{$person->level}}</span>
                </div>
            </div>
			@endunless
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">DoB</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/birthday-cake.svg" alt=""><span class="w-60 h-8 p-2">{{Carbon::parse($person->dob)->toFormattedDateString()}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Blood Group</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/tint.svg" alt=""><span class="w-60 h-8 p-2"> {{$person->blood_grp}}(ve)</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Email</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/envelope.svg" alt=""><span class="w-60 h-8 p-2"> {{$person->email}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Contact</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/mobile-alt.svg" alt=""><span class="w-60 h-8 p-2">{{$person->contact}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Total Entries</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/fingerprint.svg" alt=""><span class="w-60 h-8 p-2">{{$entry_count}}</span>
                </div>
            </div>
            <div class="flex justify-evenly mt-10 px-5">
                <label for="username" class="hidden sm:block w-28 h-8 p-2 items-center">Last Entry</label>
                <div class="flex items-center">
                    <img class="svg-label mr-5" src="/assets/svg/calendar-day.svg" alt=""><span class="w-60 h-8 p-2">{{$last_entry->toFormattedDateString()}} @ {{$last_entry->toTimeString()}}</span>
                </div>
            </div>
        </div>
        <div class="hidden md:block lg:w-7/12 md:w-6/12 justify-center">
            <div class="flex justify-center px-5 py-11">
                <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="MIST_Logo" class="w-full max-w-lg">
            </div>
        </div>
    </div>

@endsection