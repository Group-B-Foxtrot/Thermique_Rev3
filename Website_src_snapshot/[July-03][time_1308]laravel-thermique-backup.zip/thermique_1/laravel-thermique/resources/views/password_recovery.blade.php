@extends('layouts.layout')

@section('content')
    @include('inc.sidenav', ['logo_option' => 'hidden'])

    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Password Recovery</p>
        
        <div class="grid justify-items-center">
            <form class="grid justify-items-end" action="{{ route('password.email') }}" method="POSt">
            @csrf
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/envelope.svg" alt=""><input id="email" type="email" class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 form-control @error('email') is-invalid @enderror" name="email" required autocomplete="email" placeholder="Email">
                </p>
                @error('email')
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert">{{ $message }}</span>
                @enderror
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/mobile-alt.svg" alt=""><input class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="phone" name="contact" placeholder="Contact No." required>
                </p>
                <p class="mt-5">
                    <button class="flex justify-center items-center bg-green-600 w-52 h-8 mr-4 rounded-md text-white" type="submit"><img class="svg-btn mr-3" src="/assets/svg/check.svg" alt="">Proceed</button>
                </p>
                <p class="mt-5">
                    <button class= "flex justify-center items-center bg-yellow-400 w-52 h-8 mr-4 rounded-md" type="button" onclick="window.location.href='sign-in'"><img class="svg-btn mr-3" src="/assets/svg/arrow-left.svg" alt="">Go Back to Sign In</button>
                </p>
            </form>
        </div>
    </div>
@endsection