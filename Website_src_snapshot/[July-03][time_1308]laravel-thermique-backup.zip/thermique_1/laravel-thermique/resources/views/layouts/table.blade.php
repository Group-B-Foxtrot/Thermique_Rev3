@php
    $i=1;
@endphp
<div class="m-5 flex justify-center">
    <table class="text-sm text-center">
        <tr class="bg-blue-600 text-white border-2 border-blue-600">
            <th class="border-r-2 border-white">Serial No</th>
            <th class="w-64 border-l-2 border-r-2 border-white">Person ID</th>
            <th class="w-52 border-l-2 border-r-2 border-white">Temperature (°F)</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Date</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Time (Hrs)</th>
            <th class="w-36 border-l-2 border-white">Gate / Booth</th>
        </th>
        @if (count($rows)==0)
        <tr class="bg-blue-200 border-2 border-blue-600">
            <td class="border-l-2 border-r-2 border-blue-600 italic" colspan="6">Nothing to show here</td>
        </tr>
        @endif

        @foreach ($rows as $row)
            @if ($i % 2 == 1)
            <tr class="bg-white border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600">{{$i++}}</td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600">{{$row->person_id}}</td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600">{{$row->temperature}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{$row->date}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{$row->time}}</td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600">{{$row->gate}}</td>
            </tr>
            @else
            <tr class="bg-blue-200 border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600">{{$i++}}</td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600">{{$row->person_id}}</td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600">{{$row->temperature}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{$row->date}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{$row->time}}</td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600">{{$row->gate}}</td>
            </tr>
            @endif
        @endforeach
    </table>
</div>