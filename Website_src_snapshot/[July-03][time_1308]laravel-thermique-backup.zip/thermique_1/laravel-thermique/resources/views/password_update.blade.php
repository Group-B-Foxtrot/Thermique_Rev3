@extends('layouts.layout')

@section('content')
    <div class="flex justify-center pt-20 pb-5">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Update Password</p>
        
        <div class="grid justify-items-center">
            <form class="grid justify-items-end" method="POST" action="{{ route('password.update') }}">
                @csrf
                <input type="hidden" name="token" value="{{ $token }}">
                <input id="email" type="hidden" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email">
                
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/key.svg" alt=""><input id="password" class="form-control @error('password') is-invalid @enderror border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="password" name="password" placeholder="New Password" required autocomplete="new-password">
                </p>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/unlock-alt.svg" alt=""><input id="password-confirm" class="form-control border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="password" name="password_confirmation" placeholder="Confirm Password" required autocomplete="new-password">
                </p>
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/check-square.svg" alt=""><input class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 " type="number" name="username" placeholder="Verification Code">
                </p>

                @error('email')
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert">{{ $message }}</span>
                @enderror
                @error('password')
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert">{{ $message }}</span>
                @enderror
                
                <div class="grid justify-items-center">
                    <p class="mt-10">Didn't receive any code?</p>
                    <p class="mt-2">
                        <button class= "flex justify-center items-center bg-yellow-400 w-52 h-8 mr-4 rounded-md" type="submit"><img class="svg-btn mr-3" src="/assets/svg/paper-plane.svg" alt="">Resend Code</button>
                    </p>
                </div>

                <p class="mt-5">
                    <button class="flex justify-center items-center bg-green-600 w-52 h-8 mr-4 rounded-md text-white" type="submit"><img class="svg-btn mr-3" src="/assets/svg/check.svg" alt="">Proceed</button>
                </p>
            </form>
        </div>
    </div>
@endsection