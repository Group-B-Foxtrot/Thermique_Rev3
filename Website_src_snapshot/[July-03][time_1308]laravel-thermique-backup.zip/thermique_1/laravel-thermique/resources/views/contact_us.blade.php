@extends('layouts.layout')

@section('content')
    @include('inc.sidenav', ['logo_option' => 'hidden'])
    
    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>    

    <h1 class="text-center font-mullingar text-lg">The Team</h1>

    <div class="flex justify-evenly mt-5 lg:justify-center lg:gap-5">
        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex gap-2">Ishraq<span class="hidden sm:block"> Hasan</span></li>
                <li class="text-xs sm:text-sm flex">ishraq10199<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>

        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex gap-2">
                    <span class="hidden md:block">Muhammad</span>
                    Munswarim<span class="hidden sm:block"> Khan</span></li>
                <li class="text-xs sm:text-sm flex">munswarim<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>
    </div>

    <div class="flex justify-evenly mt-5 lg:justify-center lg:gap-5">
        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex gap-2"><span class="hidden sm:block">Md Rokonuzzaman </span>Reza</li>
                <li class="text-xs sm:text-sm flex">emonreza86<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>

        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex">
                    <span class="hidden sm:block">Kazi Tasnim Rahman</span>
                    <span class="block sm:hidden">Naomi</span>
                </li>
                <li class="text-xs sm:text-sm flex">tasnim.naomi<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>
    </div>

    <div class="flex justify-evenly mt-5 lg:justify-center lg:gap-5">
        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex gap-2">Shaqran<span class="hidden sm:block"> Bin Saleh</span></li>
                <li class="text-xs sm:text-sm flex">shaqran39<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>

        <div class="flex">
            <img src="/assets/img/Scorn-1080P-Wallpaper (2).jpg" alt="" class="w-16 h-12 rounded-full mr-7">
            <ul class="w-24 sm:w-48">
                <li class="text-base flex gap-2">Tashfia<span class="hidden sm:block"> Fatema</span></li>
                <li class="text-xs sm:text-sm flex">tashfiafatema<span class="hidden sm:block">@gmail.com</span></li>
            </ul>
        </div>
    </div>
@endsection