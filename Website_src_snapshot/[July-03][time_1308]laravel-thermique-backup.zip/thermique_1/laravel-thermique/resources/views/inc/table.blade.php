@php
    use Carbon\Carbon;
    $i=1;
@endphp
<div class="m-5 pb-10 flex justify-center">
    <table class="text-sm text-center">
        <tr class="bg-blue-600 text-white border-2 border-blue-600">
            <th class="border-r-2 border-white">Serial No</th>
            <th class="w-40 border-l-2 border-r-2 border-white">Person ID <span class="italic"> (link) </span></th>
            <th class="w-64 border-l-2 border-r-2 border-white">Name</th>
			<th class="w-40 border-l-2 border-r-2 border-white">Category</th>
            <th class="w-52 border-l-2 border-r-2 border-white">Temperature (°F)</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Date</th>
            <th class="w-56 border-l-2 border-r-2 border-white">Time (Hrs)</th>
            <th class="w-36 border-l-2 border-white">Gate / Booth</th>
        </th>
        @if (count($rows)==0)
        <tr class="bg-blue-200 border-2 border-blue-600">
            <td class="border-l-2 border-r-2 border-blue-600 italic" colspan="8">Nothing to show here</td>
        </tr>
        @endif

        @foreach ($rows as $row)
            @if ($i % 2 == 1)
            <tr class="bg-white border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600">{{$i++}}</td>
                <td class="w-40 border-l-2 border-r-2 border-blue-600"><a href="/person/{{$row->id}}" class="hover:text-red-600 hover:underline">{{$row->id}}</a></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600">@if ($row->category=="Faculty"){{$row->level}} @endif{{$row->name}}</td>
				<td class="w-40 border-l-2 border-r-2 border-blue-600">{{$row->category}} @if ($row->category=="Student")(L - {{$row->level}})@endif</td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600">{{$row->temperature}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{Carbon::parse($row->timestamp)->toFormattedDateString()}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{Carbon::parse($row->timestamp)->toTimeString()}}</td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600">{{$row->gate}}</td>
            </tr>
            @else
            <tr class="bg-blue-200 border-2 border-blue-600">
                <td class="border-l-2 border-r-2 border-blue-600">{{$i++}}</td>
                <td class="w-40 border-l-2 border-r-2 border-blue-600"><a href="/person/{{$row->id}}" class="hover:text-red-600 hover:underline">{{$row->id}}</a></td>
                <td class="w-64 border-l-2 border-r-2 border-blue-600">@if ($row->category=="Faculty"){{$row->level}} @endif{{$row->name}}</td>
				<td class="w-40 border-l-2 border-r-2 border-blue-600">{{$row->category}} @if ($row->category=="Student")(Lv-{{$row->level}})@endif</td>
                <td class="w-52 border-l-2 border-r-2 border-blue-600">{{$row->temperature}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{Carbon::parse($row->timestamp)->toFormattedDateString()}}</td>
                <td class="w-56 border-l-2 border-r-2 border-blue-600">{{Carbon::parse($row->timestamp)->toTimeString()}}</td>
                <td class="w-36 border-l-2 border-r-2 border-blue-600">{{$row->gate}}</td>
            </tr>
            @endif
        @endforeach
    </table>
</div>