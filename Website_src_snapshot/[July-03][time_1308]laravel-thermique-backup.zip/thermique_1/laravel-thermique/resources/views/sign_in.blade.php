@extends('layouts.layout')

@section('content')

    @auth
        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
        <script>
            document.getElementById('logout-form').submit();
        </script>
    @endauth
    
    @include('inc.sidenav', ['logo_option' => 'hidden'])

    <div class="flex justify-center pt-11 pb-5 lg:pt-0 md:pt-8">
        <img src="/assets/img/MIST_Logo.png" alt="MIST_Logo" style="height: 123px; width: auto;">
    </div>
    <div class="flex justify-center">
        <h1 class="font-mullingar uppercase text text-4xl lg:text-7xl md:text-5xl">Thermique</h1>
    </div>
    
    <div>
        <p class="text-center">Sign In</p>
        
        <div class="grid justify-items-center">
            <form class="grid justify-items-end" action="{{ route('login') }}" method="POST">
            @csrf
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/user-shield.svg" alt=""><input id="email" type="email" class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 form-control @error('email') is-invalid @enderror" name="email" placeholder="Email" required autocomplete="email">
                </p>
                @error('email')
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert">{{ $message }}</span>
                @enderror
                <p class="flex items-center mt-5">
                    <img class="svg-label mr-5" src="/assets/svg/key.svg" alt=""><input id="password" type="password" class="border-black border w-60 h-8 p-2 rounded-full focus:outline-none focus:ring focus:border-blue-300 form-control @error('password') is-invalid @enderror" name="password" placeholder="Password" required autocomplete="current-password">
                </p>
                @error('password')
                    <span class="invalid-feedback mt-2 pr-1 text-xs text-red-600" role="alert">{{ $message }}</span>
                @enderror
                <p class="mt-5">
                    <button class="flex justify-center items-center bg-green-600 w-52 h-8 mr-4 rounded-md text-white" type="submit"><img class="svg-btn mr-3" src="/assets/svg/check.svg" alt="">Sign in</button>
                </p>
                <p class="mt-5">
                    <button class= "flex justify-center items-center bg-red-500 w-52 h-8 mr-4 rounded-md text-white" type="button" onclick="window.location.href='password-recovery'"><img class="svg-btn mr-3" src="/assets/svg/exclamation-circle.svg" alt="">Forgot Password</button>
                </p>
            </form>
        </div>
    </div>
@endsection