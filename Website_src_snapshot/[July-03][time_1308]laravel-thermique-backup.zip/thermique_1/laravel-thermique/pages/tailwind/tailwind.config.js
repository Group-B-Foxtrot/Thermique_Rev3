module.exports = {
  purge: [],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      fontFamily: {
        mullingar: ["Mullingar"],
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
