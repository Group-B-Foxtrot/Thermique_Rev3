<?php
//require_once 'C:\Users\USER\vendor\autoload.php';
require_once '/workspace/Thermique/dummy_folder/vendor/autoload.php';

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

use App\Models\Record;
use App\Models\Person;
use Carbon\Carbon;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', function () {
    return view('/welcome');
});

Route::get('/', function () {
    return redirect('/home');
});


Route::get('/sign-in', function () {
    return view('sign_in', ['page_title' => 'Thermique - Sign in', 'background' => 'bg-lace']);
});
Route::get('/password-recovery', function () {
    return view('password_recovery', ['page_title' => 'Password Recovery', 'background' => 'bg-lace']);
});
Route::get('/password-edit-request', function () {
    return view('password_notice', ['page_title' => 'Password Update Request', 'background' => 'bg-lace']);
});
// Route::get('/password-update/{token}', function ($token) {
//     return view('password_update', ['page_title' => 'Password Update', 'background' => 'bg-lace', 'token' => $token, 'email' => request()->old('email')]);
// });
// The code above^ is buggy and has been reimplemented in ResetsPasswords.php

Route::get('/contact-us', function(){
    return view('contact_us', ['page_title' => 'Contact Us', 'background' => 'bg-lace']);
});

Route::get('/about', function(){
    return view('about', ['page_title' => 'About This Project', 'background' => 'bg-lace']);
});


Auth::routes();

Route::get('/index', [App\Http\Controllers\HomeController::class, 'index']);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'home']);
Route::get('/notification', [App\Http\Controllers\HomeController::class, 'alert_notification']);
Route::get('/manage-account', [App\Http\Controllers\HomeController::class, 'manage_account']);
//Route::get('/contact-us', [App\Http\Controllers\HomeController::class, 'contact_us']);
//Route::get('/about', [App\Http\Controllers\HomeController::class, 'about']);

Route::get('/person/{id}', [App\Http\Controllers\HomeController::class, 'person']);

Route::post('/home', [App\Http\Controllers\HomeController::class, 'home_search']);

Route::post('/manage-account', [App\Http\Controllers\HomeController::class, 'update_account']);

Route::get('/absent-list', [App\Http\Controllers\HomeController::class, 'absent']);
Route::post('/absent-list', [App\Http\Controllers\HomeController::class, 'absent_search']);